blender --command extension build
